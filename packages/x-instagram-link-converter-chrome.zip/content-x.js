// Content script pour X.com et Twitter.com
// Injecte des boutons pour copier les liens vers des domaines alternatifs sur chaque post

// Charger les utilitaires (injectés via manifest)
// Note: config.js et utils.js doivent être chargés avant ce script dans le manifest

/**
 * Extrait l'URL spécifique d'un post depuis son élément article
 */
function getPostUrl(articleElement) {
  // Méthode 1: Chercher un lien avec href contenant /status/
  const statusLink = articleElement.querySelector('a[href*="/status/"]');
  if (statusLink) {
    const href = statusLink.getAttribute('href');
    if (href) {
      // Si c'est un lien relatif, le convertir en absolu
      if (href.startsWith('/')) {
        return window.location.origin + href.split('?')[0];
      }
      return href.split('?')[0];
    }
  }

  // Méthode 2: Chercher dans les attributs data
  const timeElement = articleElement.querySelector('time');
  if (timeElement && timeElement.parentElement) {
    const timeLink = timeElement.parentElement.closest('a');
    if (timeLink) {
      const href = timeLink.getAttribute('href');
      if (href && href.includes('/status/')) {
        if (href.startsWith('/')) {
          return window.location.origin + href.split('?')[0];
        }
        return href.split('?')[0];
      }
    }
  }

  // Méthode 3: Chercher dans tous les liens de l'article
  const allLinks = articleElement.querySelectorAll('a[href*="/status/"]');
  for (const link of allLinks) {
    const href = link.getAttribute('href');
    if (href && href.includes('/status/')) {
      if (href.startsWith('/')) {
        return window.location.origin + href.split('?')[0];
      }
      return href.split('?')[0];
    }
  }

  return null;
}

/**
 * Ajoute les boutons de conversion à un post spécifique
 */
function addButtonsToPost(articleElement) {
  // Vérifier si les boutons sont déjà ajoutés à ce post
  const postId = articleElement.getAttribute('data-post-id') || 
                 articleElement.querySelector('article')?.getAttribute('data-post-id');
  
  // Créer un ID unique basé sur l'URL du post
  const postUrl = getPostUrl(articleElement);
  if (!postUrl) return; // Pas d'URL trouvée, on ne peut pas ajouter les boutons

  const uniqueId = 'custom-share-buttons-' + btoa(postUrl).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16);
  
  // Vérifier si les boutons existent déjà
  if (articleElement.querySelector(`#${uniqueId}`)) return;

  // Trouver le conteneur d'actions du post
  const actionGroup = articleElement.querySelector('div[role="group"][aria-label*="likes"]') ||
                      articleElement.querySelector('div[role="group"]') ||
                      articleElement.querySelector('[role="group"]');

  if (!actionGroup) return;

  const wrapper = document.createElement('div');
  wrapper.id = uniqueId;
  Object.assign(wrapper.style, {
    marginTop: '10px',
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap'
  });

  const createButton = (label, domain) => {
    const btn = document.createElement('button');
    btn.textContent = label;

    // Style Twitter Blue
    Object.assign(btn.style, {
      padding: '8px 12px',
      borderRadius: '9999px',
      border: 'none',
      backgroundColor: '#1d9bf0',
      color: '#ffffff',
      fontSize: '14px',
      fontWeight: '600',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      cursor: 'pointer',
      transition: 'background-color 0.2s ease-in-out'
    });

    btn.onmouseover = () => btn.style.backgroundColor = '#1a8cd8';
    btn.onmouseout = () => btn.style.backgroundColor = '#1d9bf0';

    btn.onclick = async () => {
      // Utiliser l'URL spécifique du post
      const postUrl = getPostUrl(articleElement);
      
      if (!postUrl) {
        createToast(CONFIG.MESSAGES.INVALID_URL + ' (Post URL not found)');
        return;
      }

      // Vérifier que c'est une URL X/Twitter valide
      if (!isValidXUrl(postUrl)) {
        createToast(CONFIG.MESSAGES.INVALID_URL + ' (X.com/Twitter)');
        return;
      }

      const newUrl = convertUrl(postUrl, domain);
      if (!newUrl) {
        createToast(CONFIG.MESSAGES.ERROR + ': Invalid URL conversion');
        return;
      }

      const success = await copyToClipboard(newUrl);
      if (success) {
        createToast(`${CONFIG.MESSAGES.COPIED}: ${domain}`);
      } else {
        createToast(CONFIG.MESSAGES.CLIPBOARD_ERROR);
      }
    };

    return btn;
  };

  // Créer les boutons pour chaque alternative X
  Object.entries(CONFIG.X_ALTERNATIVES).forEach(([key, domain]) => {
    wrapper.appendChild(createButton(`📋 ${key}`, domain));
  });

  // Insérer les boutons après le groupe d'actions
  if (actionGroup.parentNode) {
    actionGroup.parentNode.insertBefore(wrapper, actionGroup.nextSibling);
  }
}

/**
 * Parcourt tous les posts du feed et ajoute les boutons
 */
function addXButtonsToAllPosts() {
  // Trouver tous les articles/posts dans le feed
  // X utilise <article> pour les posts
  const articles = document.querySelectorAll('article[data-testid="tweet"]');
  
  // Fallback si le sélecteur ne fonctionne pas
  const articlesFallback = articles.length === 0 
    ? document.querySelectorAll('article')
    : articles;

  articlesFallback.forEach((article) => {
    // Vérifier que c'est bien un post (contient des éléments de post)
    const hasPostContent = article.querySelector('div[role="group"]') || 
                          article.querySelector('[data-testid="tweet"]') ||
                          article.querySelector('a[href*="/status/"]');
    
    if (hasPostContent) {
      addButtonsToPost(article);
    }
  });
}

// Observer pour détecter les nouveaux posts chargés dynamiquement
const observer = new MutationObserver((mutations) => {
  // Délai pour éviter trop d'exécutions
  clearTimeout(window.addXButtonsTimeout);
  window.addXButtonsTimeout = setTimeout(() => {
    addXButtonsToAllPosts();
  }, 300);
});

observer.observe(document.body, { 
  childList: true, 
  subtree: true 
});

// Exécuter immédiatement au chargement
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(addXButtonsToAllPosts, 500);
  });
} else {
  setTimeout(addXButtonsToAllPosts, 500);
}

// Réexécuter après un délai pour les chargements tardifs
setTimeout(addXButtonsToAllPosts, 1000);
setTimeout(addXButtonsToAllPosts, 2000);
