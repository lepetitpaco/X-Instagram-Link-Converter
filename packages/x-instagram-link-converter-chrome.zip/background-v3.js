// Background service worker pour Manifest V3
// Gère les menus contextuels et les actions du popup

// Configuration (doit être inline car les service workers ne peuvent pas importer)
const CONFIG = {
  X_ALTERNATIVES: {
    fixvx: 'fixvx.com',
    fixupx: 'fixupx.com',
    vxtwitter: 'vxtwitter.com'
  },
  INSTAGRAM_ALTERNATIVES: {
    kkinstagram: 'kkinstagram.com'
  },
  X_DOMAINS: ['x.com', 'twitter.com'],
  INSTAGRAM_DOMAINS: ['www.instagram.com', 'instagram.com']
};

/**
 * Convertit une URL vers un domaine alternatif
 */
function convertUrl(url, newDomain) {
  try {
    const cleanUrl = url.split('?')[0];
    const urlObj = new URL(cleanUrl);
    urlObj.hostname = newDomain;
    return urlObj.toString();
  } catch (e) {
    console.error('Error converting URL:', e);
    return null;
  }
}

/**
 * Vérifie si une URL est une URL X/Twitter valide
 */
function isValidXUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.X_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('x.com') || url.includes('twitter.com');
  }
}

/**
 * Vérifie si une URL est une URL Instagram valide
 */
function isValidInstagramUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.INSTAGRAM_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('instagram.com');
  }
}

// Créer les menus contextuels à l'installation
chrome.runtime.onInstalled.addListener(() => {
  // Menus pour X.com et Twitter.com
  chrome.contextMenus.create({
    id: 'copy-x-fixvx-page',
    title: '📋 Copy fixvx link of this X page',
    contexts: ['page'],
    documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
  });

  chrome.contextMenus.create({
    id: 'copy-x-fixupx-page',
    title: '📋 Copy fixupx link of this X page',
    contexts: ['page'],
    documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
  });

  chrome.contextMenus.create({
    id: 'copy-x-vxtwitter-page',
    title: '📋 Copy vxtwitter link of this X page',
    contexts: ['page'],
    documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
  });

  // Menu pour Instagram
  chrome.contextMenus.create({
    id: 'copy-kkinstagram-page',
    title: '📷 Copy kkinstagram link of this Instagram page',
    contexts: ['page'],
    documentUrlPatterns: ['*://www.instagram.com/*', '*://instagram.com/*']
  });
});

// Gérer les clics sur les menus contextuels
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (!tab || !tab.url) {
    console.error('No tab or URL available');
    return;
  }

  const rawUrl = tab.url.split('?')[0];
  let replacementDomain = null;

  switch (info.menuItemId) {
    case 'copy-x-fixvx-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.fixvx;
      break;
    case 'copy-x-fixupx-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.fixupx;
      break;
    case 'copy-x-vxtwitter-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.vxtwitter;
      break;
    case 'copy-kkinstagram-page':
      replacementDomain = CONFIG.INSTAGRAM_ALTERNATIVES.kkinstagram;
      break;
    default:
      console.error('Unknown menu item:', info.menuItemId);
      return;
  }

  if (!replacementDomain) {
    console.error('No replacement domain found');
    return;
  }

  const newUrl = convertUrl(rawUrl, replacementDomain);
  if (!newUrl) {
    console.error('Failed to convert URL');
    return;
  }

  // Utiliser chrome.scripting.executeScript pour Manifest V3
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (text) => {
        navigator.clipboard.writeText(text).then(() => {
          // Afficher une notification visuelle
          const toast = document.createElement('div');
          toast.textContent = `✅ Copied: ${text}`;
          Object.assign(toast.style, {
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: '#1d9bf0',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '9999px',
            fontSize: '14px',
            fontWeight: '600',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            zIndex: '9999',
            pointerEvents: 'none'
          });
          document.body.appendChild(toast);
          setTimeout(() => toast.remove(), 2000);
        }).catch(err => {
          console.error('Clipboard write error:', err);
        });
      },
      args: [newUrl]
    });
  } catch (error) {
    console.error('Error executing script:', error);
  }
});
