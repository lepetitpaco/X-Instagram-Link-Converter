// Popup script pour l'extension
// Unifie l'API chrome/browser pour compatibilité

// Configuration inline (même que config.js pour éviter les dépendances)
const CONFIG = {
  X_ALTERNATIVES: {
    fixvx: 'fixvx.com',
    fixupx: 'fixupx.com',
    vxtwitter: 'vxtwitter.com'
  },
  INSTAGRAM_ALTERNATIVES: {
    kkinstagram: 'kkinstagram.com'
  },
  X_DOMAINS: ['x.com', 'twitter.com'],
  INSTAGRAM_DOMAINS: ['www.instagram.com', 'instagram.com'],
  MESSAGES: {
    COPIED: '✅ Copied',
    ERROR: '❌ Error',
    INVALID_URL: '❌ Invalid URL',
    NOT_SUPPORTED: '❌ This page is not supported.',
    CLIPBOARD_ERROR: '❌ Clipboard error'
  }
};

// Unifier l'API chrome/browser
const browserAPI = typeof chrome !== 'undefined' ? chrome : (typeof browser !== 'undefined' ? browser : null);

if (!browserAPI) {
  document.getElementById('status').textContent = CONFIG.MESSAGES.ERROR + ': Browser API not available';
  document.getElementById('status').className = 'status-error';
}

/**
 * Convertit une URL vers un domaine alternatif
 */
function convertUrl(url, newDomain) {
  try {
    const cleanUrl = url.split('?')[0];
    const urlObj = new URL(cleanUrl);
    urlObj.hostname = newDomain;
    return urlObj.toString();
  } catch (e) {
    console.error('Error converting URL:', e);
    return null;
  }
}

/**
 * Vérifie si une URL est une URL X/Twitter valide
 */
function isValidXUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.X_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('x.com') || url.includes('twitter.com');
  }
}

/**
 * Vérifie si une URL est une URL Instagram valide
 */
function isValidInstagramUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.INSTAGRAM_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('instagram.com');
  }
}

/**
 * Obtient le lien du post actuel et le convertit
 */
async function getPostLink(replacementHost, expectedType = 'x') {
  if (!browserAPI) {
    showStatus(CONFIG.MESSAGES.ERROR + ': Browser API not available', 'error');
    return;
  }

  const status = document.getElementById('status');
  status.textContent = '';
  status.className = '';

  try {
    // Utiliser l'API unifiée
    const tabs = await new Promise((resolve, reject) => {
      if (browserAPI.tabs && browserAPI.tabs.query) {
        browserAPI.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (browserAPI.runtime.lastError) {
            reject(new Error(browserAPI.runtime.lastError.message));
          } else {
            resolve(tabs);
          }
        });
      } else {
        reject(new Error('Tabs API not available'));
      }
    });

    if (!tabs || tabs.length === 0) {
      showStatus(CONFIG.MESSAGES.ERROR + ': No active tab found', 'error');
      return;
    }

    const tab = tabs[0];
    const rawUrl = tab.url;

    if (!rawUrl) {
      showStatus(CONFIG.MESSAGES.ERROR + ': No URL available', 'error');
      return;
    }

    // Vérifier le type d'URL
    const isSupported = expectedType === 'x' 
      ? isValidXUrl(rawUrl)
      : isValidInstagramUrl(rawUrl);

    if (!isSupported) {
      const platform = expectedType === 'x' ? 'X.com/Twitter' : 'Instagram';
      showStatus(CONFIG.MESSAGES.NOT_SUPPORTED + ` (${platform})`, 'error');
      return;
    }

    const cleanUrl = rawUrl.split('?')[0];
    const finalUrl = convertUrl(cleanUrl, replacementHost);

    if (!finalUrl) {
      showStatus(CONFIG.MESSAGES.ERROR + ': URL conversion failed', 'error');
      return;
    }

    // Copier dans le presse-papiers
    try {
      await navigator.clipboard.writeText(finalUrl);
      showStatus(`${CONFIG.MESSAGES.COPIED}: ${finalUrl}`, 'success');
    } catch (e) {
      console.error('Clipboard write error:', e);
      showStatus(CONFIG.MESSAGES.CLIPBOARD_ERROR + ': ' + e.message, 'error');
    }
  } catch (e) {
    console.error('Error getting post link:', e);
    showStatus(CONFIG.MESSAGES.ERROR + ': ' + e.message, 'error');
  }
}

/**
 * Affiche un message de statut
 */
function showStatus(message, type) {
  const status = document.getElementById('status');
  status.textContent = message;
  status.className = type === 'success' ? 'status-success' : 'status-error';
  
  // Effacer après 3 secondes
  setTimeout(() => {
    status.textContent = '';
    status.className = '';
  }, 3000);
}

// Event listeners pour les boutons X/Twitter
document.getElementById('copy-fixvx').addEventListener('click', () => {
  getPostLink(CONFIG.X_ALTERNATIVES.fixvx, 'x');
});

document.getElementById('copy-fixupx').addEventListener('click', () => {
  getPostLink(CONFIG.X_ALTERNATIVES.fixupx, 'x');
});

document.getElementById('copy-vxtwitter').addEventListener('click', () => {
  getPostLink(CONFIG.X_ALTERNATIVES.vxtwitter, 'x');
});

// Event listener pour Instagram
document.getElementById('copy-kkinstagram').addEventListener('click', () => {
  getPostLink(CONFIG.INSTAGRAM_ALTERNATIVES.kkinstagram, 'instagram');
});
