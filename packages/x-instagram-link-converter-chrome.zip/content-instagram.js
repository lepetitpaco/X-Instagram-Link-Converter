// Content script pour Instagram.com
// Ajoute des boutons visibles sous chaque post pour convertir les liens vers kkinstagram.com

// Charger les utilitaires (injectés via manifest)
// Note: config.js et utils.js doivent être chargés avant ce script dans le manifest

/**
 * Extrait l'URL spécifique d'un post Instagram depuis son élément article
 */
function getPostUrl(articleElement) {
  // Méthode 1: Chercher un lien avec href contenant /p/ ou /reel/
  const postLink = articleElement.querySelector('a[href*="/p/"], a[href*="/reel/"]');
  if (postLink) {
    const href = postLink.getAttribute('href');
    if (href) {
      // Si c'est un lien relatif, le convertir en absolu
      if (href.startsWith('/')) {
        return window.location.origin + href.split('?')[0];
      }
      return href.split('?')[0];
    }
  }

  // Méthode 2: Chercher dans les liens time (timestamp du post)
  const timeElement = articleElement.querySelector('time');
  if (timeElement && timeElement.parentElement) {
    const timeLink = timeElement.parentElement.closest('a');
    if (timeLink) {
      const href = timeLink.getAttribute('href');
      if (href && (href.includes('/p/') || href.includes('/reel/'))) {
        if (href.startsWith('/')) {
          return window.location.origin + href.split('?')[0];
        }
        return href.split('?')[0];
      }
    }
  }

  // Méthode 3: Chercher dans tous les liens de l'article
  const allLinks = articleElement.querySelectorAll('a[href*="/p/"], a[href*="/reel/"]');
  for (const link of allLinks) {
    const href = link.getAttribute('href');
    if (href && (href.includes('/p/') || href.includes('/reel/'))) {
      if (href.startsWith('/')) {
        return window.location.origin + href.split('?')[0];
      }
      return href.split('?')[0];
    }
  }

  return null;
}

/**
 * Trouve le conteneur des boutons d'engagement (like, comment, share, etc.)
 */
function findEngagementContainer(articleElement) {
  // Méthode 1: Chercher la section avec les boutons d'action
  const actionSection = articleElement.querySelector('section[role="button"]') ||
                       articleElement.querySelector('div[role="button"]') ||
                       articleElement.querySelector('section > div');

  // Méthode 2: Chercher après les boutons like/comment/share
  const likeButton = articleElement.querySelector('svg[aria-label*="Like"], svg[aria-label*="like"]');
  if (likeButton) {
    const buttonContainer = likeButton.closest('section, div[role="button"], div');
    if (buttonContainer && buttonContainer.parentElement) {
      return buttonContainer.parentElement;
    }
  }

  // Méthode 3: Chercher la section qui contient les métriques (likes, comments)
  const metricsSection = articleElement.querySelector('section');
  if (metricsSection) {
    // Chercher après la section des métriques
    return metricsSection;
  }

  // Méthode 4: Fallback - chercher n'importe quelle section dans l'article
  return articleElement.querySelector('section') || articleElement;
}

/**
 * Ajoute les boutons de conversion à un post Instagram spécifique
 */
function addButtonsToPost(articleElement) {
  // Créer un ID unique basé sur l'URL du post
  const postUrl = getPostUrl(articleElement);
  if (!postUrl) return; // Pas d'URL trouvée, on ne peut pas ajouter les boutons

  const uniqueId = 'custom-instagram-buttons-' + btoa(postUrl).replace(/[^a-zA-Z0-9]/g, '').substring(0, 16);
  
  // Vérifier si les boutons existent déjà
  if (articleElement.querySelector(`#${uniqueId}`)) return;

  // Trouver où insérer les boutons (après les boutons d'engagement)
  const container = findEngagementContainer(articleElement);
  if (!container) return;

  const wrapper = document.createElement('div');
  wrapper.id = uniqueId;
  Object.assign(wrapper.style, {
    marginTop: '12px',
    marginBottom: '8px',
    display: 'flex',
    gap: '8px',
    flexWrap: 'wrap',
    padding: '0 8px'
  });

  const createButton = (domain) => {
    const btn = document.createElement('button');
    
    // Créer une icône SVG stylée (camera/photo icon) - utilisation sécurisée
    const iconSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    iconSvg.setAttribute('width', '18');
    iconSvg.setAttribute('height', '18');
    iconSvg.setAttribute('viewBox', '0 0 24 24');
    iconSvg.setAttribute('fill', 'none');
    Object.assign(iconSvg.style, {
      display: 'inline-block',
      verticalAlign: 'middle',
      marginRight: '6px'
    });
    
    // Path 1
    const path1 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path1.setAttribute('d', 'M12 15.5C13.933 15.5 15.5 13.933 15.5 12C15.5 10.067 13.933 8.5 12 8.5C10.067 8.5 8.5 10.067 8.5 12C8.5 13.933 10.067 15.5 12 15.5Z');
    path1.setAttribute('stroke', 'currentColor');
    path1.setAttribute('stroke-width', '2');
    path1.setAttribute('stroke-linecap', 'round');
    path1.setAttribute('stroke-linejoin', 'round');
    iconSvg.appendChild(path1);
    
    // Path 2
    const path2 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path2.setAttribute('d', 'M20.5 7H19L17 5H7L5 7H3.5C2.67 7 2 7.67 2 8.5V19.5C2 20.33 2.67 21 3.5 21H20.5C21.33 21 22 20.33 22 19.5V8.5C22 7.67 21.33 7 20.5 7Z');
    path2.setAttribute('stroke', 'currentColor');
    path2.setAttribute('stroke-width', '2');
    path2.setAttribute('stroke-linecap', 'round');
    path2.setAttribute('stroke-linejoin', 'round');
    iconSvg.appendChild(path2);
    
    // Path 3
    const path3 = document.createElementNS('http://www.w3.org/2000/svg', 'path');
    path3.setAttribute('d', 'M16 12C16 14.2091 14.2091 16 12 16C9.79086 16 8 14.2091 8 12C8 9.79086 9.79086 8 12 8C14.2091 8 16 9.79086 16 12Z');
    path3.setAttribute('stroke', 'currentColor');
    path3.setAttribute('stroke-width', '1.5');
    path3.setAttribute('stroke-linecap', 'round');
    path3.setAttribute('stroke-linejoin', 'round');
    iconSvg.appendChild(path3);
    
    // Texte
    const textSpan = document.createElement('span');
    textSpan.textContent = 'kkinstagram';
    Object.assign(textSpan.style, {
      verticalAlign: 'middle'
    });
    
    btn.appendChild(iconSvg);
    btn.appendChild(textSpan);

    // Style Instagram amélioré (plus moderne et fun)
    Object.assign(btn.style, {
      padding: '8px 16px',
      borderRadius: '12px',
      border: 'none',
      background: 'linear-gradient(135deg, #833ab4 0%, #fd1d1d 50%, #fcb045 100%)',
      color: '#ffffff',
      fontSize: '13px',
      fontWeight: '600',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif',
      cursor: 'pointer',
      transition: 'all 0.3s ease-in-out',
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      boxShadow: '0 2px 8px rgba(131, 58, 180, 0.3)',
      position: 'relative',
      overflow: 'hidden'
    });

    // Effet hover avec animation
    btn.onmouseover = () => {
      btn.style.transform = 'scale(1.05)';
      btn.style.boxShadow = '0 4px 12px rgba(131, 58, 180, 0.5)';
    };
    btn.onmouseout = () => {
      btn.style.transform = 'scale(1)';
      btn.style.boxShadow = '0 2px 8px rgba(131, 58, 180, 0.3)';
    };
    
    // Effet de clic
    btn.onmousedown = () => {
      btn.style.transform = 'scale(0.98)';
    };
    btn.onmouseup = () => {
      btn.style.transform = 'scale(1.05)';
    };

    btn.onclick = async () => {
      // Utiliser l'URL spécifique du post
      const postUrl = getPostUrl(articleElement);
      
      if (!postUrl) {
        createToast(CONFIG.MESSAGES.INVALID_URL + ' (Post URL not found)');
        return;
      }

      // Vérifier que c'est une URL Instagram valide
      if (!isValidInstagramUrl(postUrl)) {
        createToast(CONFIG.MESSAGES.INVALID_URL + ' (Instagram)');
        return;
      }

      const newUrl = convertUrl(postUrl, domain);
      if (!newUrl) {
        createToast(CONFIG.MESSAGES.ERROR + ': Invalid URL conversion');
        return;
      }

      const success = await copyToClipboard(newUrl);
      if (success) {
        createToast(`${CONFIG.MESSAGES.COPIED}: ${domain}`);
      } else {
        createToast(CONFIG.MESSAGES.CLIPBOARD_ERROR);
      }
    };

    return btn;
  };

  // Créer le bouton pour kkinstagram avec style amélioré
  Object.entries(CONFIG.INSTAGRAM_ALTERNATIVES).forEach(([key, domain]) => {
    wrapper.appendChild(createButton(domain));
  });

  // Insérer les boutons après le conteneur d'engagement
  // Chercher la section des métriques (likes, comments) pour insérer après
  const metricsSection = articleElement.querySelector('section');
  if (metricsSection && metricsSection.nextSibling) {
    metricsSection.parentNode.insertBefore(wrapper, metricsSection.nextSibling);
  } else if (container && container.parentElement) {
    // Insérer après le conteneur
    container.parentElement.insertBefore(wrapper, container.nextSibling);
  } else {
    // Dernier recours : ajouter à la fin de l'article
    articleElement.appendChild(wrapper);
  }
}

/**
 * Parcourt tous les posts du feed et ajoute les boutons
 */
function addButtonsToAllPosts() {
  // Trouver tous les articles/posts dans le feed Instagram
  // Instagram utilise <article> pour les posts
  const articles = document.querySelectorAll('article');
  
  articles.forEach((article) => {
    // Vérifier que c'est bien un post (contient des éléments de post)
    const hasPostContent = article.querySelector('a[href*="/p/"]') || 
                          article.querySelector('a[href*="/reel/"]') ||
                          article.querySelector('section');
    
    if (hasPostContent) {
      addButtonsToPost(article);
    }
  });
}

// Observer pour détecter les nouveaux posts chargés dynamiquement
const observer = new MutationObserver((mutations) => {
  // Délai pour éviter trop d'exécutions
  clearTimeout(window.addInstagramButtonsTimeout);
  window.addInstagramButtonsTimeout = setTimeout(() => {
    addButtonsToAllPosts();
  }, 300);
});

observer.observe(document.body, { 
  childList: true, 
  subtree: true 
});

// Exécuter immédiatement au chargement
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    setTimeout(addButtonsToAllPosts, 500);
  });
} else {
  setTimeout(addButtonsToAllPosts, 500);
}

// Réexécuter après un délai pour les chargements tardifs
setTimeout(addButtonsToAllPosts, 1000);
setTimeout(addButtonsToAllPosts, 2000);
