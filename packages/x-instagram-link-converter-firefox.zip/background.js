// Background script pour Manifest V2
// Gère les menus contextuels et les actions du popup

// Configuration inline (pour compatibilité)
const CONFIG = {
  X_ALTERNATIVES: {
    fixvx: 'fixvx.com',
    fixupx: 'fixupx.com',
    vxtwitter: 'vxtwitter.com'
  },
  INSTAGRAM_ALTERNATIVES: {
    kkinstagram: 'kkinstagram.com'
  },
  X_DOMAINS: ['x.com', 'twitter.com'],
  INSTAGRAM_DOMAINS: ['www.instagram.com', 'instagram.com']
};

/**
 * Convertit une URL vers un domaine alternatif
 */
function convertUrl(url, newDomain) {
  try {
    const cleanUrl = url.split('?')[0];
    const urlObj = new URL(cleanUrl);
    urlObj.hostname = newDomain;
    return urlObj.toString();
  } catch (e) {
    console.error('Error converting URL:', e);
    return null;
  }
}

/**
 * Vérifie si une URL est une URL X/Twitter valide
 */
function isValidXUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.X_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('x.com') || url.includes('twitter.com');
  }
}

/**
 * Vérifie si une URL est une URL Instagram valide
 */
function isValidInstagramUrl(url) {
  if (!url) return false;
  try {
    const urlObj = new URL(url);
    return CONFIG.INSTAGRAM_DOMAINS.some(domain => 
      urlObj.hostname === domain || urlObj.hostname.endsWith('.' + domain)
    );
  } catch {
    return url.includes('instagram.com');
  }
}

// Créer les menus contextuels à l'installation
chrome.runtime.onInstalled.addListener(() => {
  try {
    // Menus pour X.com et Twitter.com
    chrome.contextMenus.create({
      id: 'copy-x-fixvx-page',
      title: '📋 Copy fixvx link of this X page',
      contexts: ['page'],
      documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error creating fixvx menu:', chrome.runtime.lastError);
      }
    });

    chrome.contextMenus.create({
      id: 'copy-x-fixupx-page',
      title: '📋 Copy fixupx link of this X page',
      contexts: ['page'],
      documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error creating fixupx menu:', chrome.runtime.lastError);
      }
    });

    chrome.contextMenus.create({
      id: 'copy-x-vxtwitter-page',
      title: '📋 Copy vxtwitter link of this X page',
      contexts: ['page'],
      documentUrlPatterns: ['*://x.com/*', '*://twitter.com/*']
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error creating vxtwitter menu:', chrome.runtime.lastError);
      }
    });

    // Menu pour Instagram
    chrome.contextMenus.create({
      id: 'copy-kkinstagram-page',
      title: '📷 Copy kkinstagram link of this Instagram page',
      contexts: ['page'],
      documentUrlPatterns: ['*://www.instagram.com/*', '*://instagram.com/*']
    }, () => {
      if (chrome.runtime.lastError) {
        console.error('Error creating kkinstagram menu:', chrome.runtime.lastError);
      }
    });
  } catch (error) {
    console.error('Error setting up context menus:', error);
  }
});

// Gérer les clics sur les menus contextuels
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (!tab || !tab.id) {
    console.error('No tab or tab ID available');
    return;
  }

  if (!tab.url) {
    console.error('No URL available for tab');
    chrome.tabs.executeScript(tab.id, {
      code: `alert("❌ This page is not supported.")`
    }, (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error showing alert:', chrome.runtime.lastError);
      }
    });
    return;
  }

  const rawUrl = tab.url.split('?')[0];
  let replacementDomain = null;

  switch (info.menuItemId) {
    case 'copy-x-fixvx-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.fixvx;
      break;
    case 'copy-x-fixupx-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.fixupx;
      break;
    case 'copy-x-vxtwitter-page':
      replacementDomain = CONFIG.X_ALTERNATIVES.vxtwitter;
      break;
    case 'copy-kkinstagram-page':
      replacementDomain = CONFIG.INSTAGRAM_ALTERNATIVES.kkinstagram;
      break;
    default:
      console.error('Unknown menu item:', info.menuItemId);
      chrome.tabs.executeScript(tab.id, {
        code: `alert("❌ This page is not supported.")`
      }, (result) => {
        if (chrome.runtime.lastError) {
          console.error('Error showing alert:', chrome.runtime.lastError);
        }
      });
      return;
  }

  if (!replacementDomain) {
    console.error('No replacement domain found for menu item:', info.menuItemId);
    return;
  }

  const newUrl = convertUrl(rawUrl, replacementDomain);
  if (!newUrl) {
    console.error('Failed to convert URL:', rawUrl);
    chrome.tabs.executeScript(tab.id, {
      code: `alert("❌ Error: Failed to convert URL.")`
    }, (result) => {
      if (chrome.runtime.lastError) {
        console.error('Error showing alert:', chrome.runtime.lastError);
      }
    });
    return;
  }

  // Utiliser chrome.tabs.executeScript pour Manifest V2
  chrome.tabs.executeScript(tab.id, {
    code: `
      (function() {
        const url = ${JSON.stringify(newUrl)};
        navigator.clipboard.writeText(url).then(() => {
          // Afficher une notification visuelle
          const toast = document.createElement('div');
          toast.textContent = '✅ Copied: ' + url;
          Object.assign(toast.style, {
            position: 'fixed',
            top: '20px',
            left: '50%',
            transform: 'translateX(-50%)',
            backgroundColor: '#1d9bf0',
            color: '#fff',
            padding: '10px 20px',
            borderRadius: '9999px',
            fontSize: '14px',
            fontWeight: '600',
            boxShadow: '0 4px 12px rgba(0,0,0,0.15)',
            zIndex: '9999',
            pointerEvents: 'none'
          });
          document.body.appendChild(toast);
          setTimeout(() => toast.remove(), 2000);
        }).catch(err => {
          console.error('Clipboard write error:', err);
          alert('❌ Error: Failed to copy to clipboard.');
        });
      })();
    `
  }, (result) => {
    if (chrome.runtime.lastError) {
      console.error('Error executing script:', chrome.runtime.lastError);
    }
  });
});
